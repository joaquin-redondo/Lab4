const readline = require('readline');
const fs = require('fs').promises;
const yargs = require('yargs');
const { hideBin } = require('yargs/helpers');


const argv = yargs(hideBin(process.argv))
  .option('file', {
    alias: 'f',
    type: 'string',
    description: 'nombre del archivo JSON',
    default: 'productos.json',
  })
  .argv;

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});


const preguntar = (pregunta) => {
  return new Promise((resolve) => {
    rl.question(pregunta, (respuesta) => resolve(respuesta));
  });
};


const main = async () => {
  try {
    const nombre = await preguntar('Producto: ');
    const precio = parseFloat(await preguntar('Precio: '));
    const cantidad = parseInt(await preguntar('Cantidad: '));

    if (isNaN(precio) || isNaN(cantidad)) {
      console.log('error, el precio y la cantidad solo pueden ser numeros');
      rl.close();
      return;
    }

    const producto = { nombre, precio, cantidad };
    const fileName = argv.file;

    let productos = [];

    try {
      const data = await fs.readFile(fileName, 'utf-8');
      productos = JSON.parse(data);
    } catch (error) {
      if (error.code !== 'error') {
        console.log('error al leer el archivo:', error.message);
        rl.close();
        return;
      }
    }

    productos.push(producto);
    await fs.writeFile(fileName, JSON.stringify(productos, null, 2));

    console.log('producto guardado');
    console.log('contenido:', productos);

  } catch (error) {
    console.log('error:', error.message);
  } finally {
    rl.close();
  }
};

main();
